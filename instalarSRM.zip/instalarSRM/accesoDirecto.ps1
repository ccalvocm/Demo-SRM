Set-ExecutionPolicy Bypass -Scope Process -Force;
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12;
$WshShell = New-Object -comObject WScript.Shell;
$Shortcut = $WshShell.CreateShortcut([Environment]::GetFolderPath("Desktop")+"\CNR-SRM.lnk");
$Shortcut.TargetPath = "$HOME\Demo-SRM\CNR-SRM.exe";
$Shortcut.WorkingDirectory = "$HOME\Demo-SRM";
$Shortcut.Save();
start .\Demo-SRM;
