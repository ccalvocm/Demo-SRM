Set-ExecutionPolicy Bypass -Scope Process -Force;
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12;
$WshShell = New-Object -comObject WScript.Shell;
$Shortcut = $WshShell.CreateShortcut([Environment]::GetFolderPath("Desktop")+"\CNR-SRM.lnk");
$Shortcut.TargetPath = Join-Path (Get-Location).Path "\Demo-SRM\CNR-SRM.exe";
$Shortcut.WorkingDirectory = Join-Path (Get-Location).Path "\Demo-SRM";
$Shortcut.Save();
start .\Demo-SRM;
